use super::SaleAccount;
use super::UserPurchase;
use anchor_lang::prelude::*;
use anchor_spl::token::{Token, TokenAccount, Transfer, Mint, transfer};
use anchor_spl::associated_token::AssociatedToken;

use super::error::ErrorCode;

#[derive(Accounts)]
pub struct BuyToken<'info> {
    #[account(
        mut,
        seeds = [crate::TOKEN_SEED, token_mint.key().as_ref()],
        bump)]
    pub sale: Account<'info, SaleAccount>,
    
    #[account(
        mut,
        constraint = token_mint.key() == sale.token_mint,
    )]
    pub token_mint: Account<'info, Mint>,
    #[account(
        mut,
        constraint = buy_token_mint.key() == sale.buy_token_mint,
    )]
    pub buy_token_mint: Account<'info, Mint>,
    
    #[account(mut)]
    pub buyer: Signer<'info>,
    
    #[account(
        mut,
        constraint = buyer_token_account.owner == buyer.key(),
        constraint = buyer_token_account.mint == buy_token_mint.key()
    )]
    pub buyer_token_account: Account<'info, TokenAccount>,
    
    #[account(
        mut,
        constraint = sale_token_account.owner == sale.key(),
        constraint = sale_token_account.mint == buy_token_mint.key()
    )]
    pub sale_token_account: Account<'info, TokenAccount>,
    
    //增加用户购买账户，带初始化
    #[account(
        init,
        payer = buyer,
        space = 8 + core::mem::size_of::<UserPurchase>(),
        seeds = [crate::TOKEN_PURCHASE, buyer.key().as_ref(),token_mint.key().as_ref()],
        bump
    )]
    pub user_purchase: Account<'info, UserPurchase>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
}

impl<'info> BuyToken<'info> {
    pub fn process(&mut self, amount: u64) -> Result<()> {

        //判断时间到期
        let current_time = Clock::get()?.unix_timestamp;
        
        // 检查销售是否已结束
        if current_time > self.sale.end_time {
            msg!("Sale ended.");
           //返回报错
           return Err(ErrorCode::SaleEnded.into());
        }

        // 验证销售是否还有足够的代币
        if self.sale.remaining_amount == 0 {
            msg!("No tokens left for sale.");
            return Err(ErrorCode::NoTokensLeft.into());
        }
        
        // 计算可购买的代币数量
        let token_amount = amount.checked_div(self.sale.price_per_token)
            .ok_or(ErrorCode::Overflow)?;
            
        
        if token_amount == 0 {
            msg!("Amount too small to buy any tokens.");
            return Err(ErrorCode::AmountTooSmall.into());
        }

        let decimals = 10u128
        .checked_pow(self.token_mint.decimals.into())
        .ok_or(ErrorCode::Overflow)?;
    
    let token_amount_u128 = (token_amount as u128)
        .checked_mul(decimals)
        .ok_or(ErrorCode::Overflow)?;
    
    // 不超过剩余
    let actual_token_amount = std::cmp::min(token_amount_u128, self.sale.remaining_amount as u128);
    

    // 金额 = 实际购买的 token 数量（最小单位） × 单价 ÷ 精度
let amount = actual_token_amount
.checked_mul(self.sale.price_per_token as u128)
.ok_or(ErrorCode::Overflow)?
.checked_div(decimals)
.ok_or(ErrorCode::Overflow)?;

// // 最终转回 u64
// let actual_amount = u64::try_from(amount).map_err(|_| ErrorCode::Overflow)?;
//     // 价格计算
//     let actual_amount_u128 = actual_token_amount
//         .checked_mul(self.sale.price_per_token as u128)
//         .ok_or(ErrorCode::Overflow)?;
    
    // 转回 u64，如果能装下
    let actual_amount = u64::try_from(amount)
        .map_err(|_| ErrorCode::Overflow)?;

        // 执行代币转移
        transfer(
            self.into_transfer_to_buyer_context(),
            actual_amount
        )?;

        // 更新销售账户状态
        self.sale.remaining_amount = self.sale.remaining_amount.checked_sub(actual_token_amount as u64)
            .ok_or(ErrorCode::Overflow)?;

        // 如果所有代币都已售出，关闭销售
        if self.sale.remaining_amount == 0 {
            self.sale.is_active = false;
        }

        // 记录购买事件
        msg!("Bought {} tokens for {} lamports", actual_token_amount, actual_amount);


        //更改UserPurchase,判断用户是否已购买，已购买的话应该报错
        if self.user_purchase.user_address == self.buyer.key() {
            return Err(ErrorCode::UserAlreadyPurchased.into());
        }   

        self.user_purchase.user_address = self.buyer.key();
        self.user_purchase.token_amount = actual_token_amount as u64;
        self.user_purchase.token_price = self.sale.price_per_token;
        self.user_purchase.token_address = self.token_mint.key();
        self.user_purchase.purchase_amount = actual_amount;
        self.user_purchase.purchase_time = Clock::get()?.unix_timestamp;
        self.user_purchase.is_claim = false;


        Ok(())
    }

    pub fn into_transfer_to_buyer_context(&self) -> CpiContext<'_, '_, '_, 'info, Transfer<'info>> {
        CpiContext::new(
            self.token_program.to_account_info(),
            Transfer {
                from: self.buyer_token_account.to_account_info(),
                to: self.sale_token_account.to_account_info(),
                authority: self.buyer.to_account_info(),
            },
        )
    }
} 